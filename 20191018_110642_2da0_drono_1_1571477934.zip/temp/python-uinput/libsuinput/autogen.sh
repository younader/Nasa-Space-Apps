#!/bin/sh

autoreconf --install --force --symlink
